# jobportal
Job portal Site using some artificial intelligence
