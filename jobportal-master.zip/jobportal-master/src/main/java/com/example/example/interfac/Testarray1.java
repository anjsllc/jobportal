package com.example.example.interfac;
class Testarray1
{
	public static void main(String args[])
	{
	int a[] = {33,3,4,5};
	for(int i=0;i<a.length;i++)
	System.out.println(a[i]);
	}
}