package com.example.example;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ){
        System.out.println( "Hello World!" );
		App a = new App();
		
		int numberOfYears = a.calculate();
    }
	
	public int calculate(){
	
	return 11;
	}
	
}
