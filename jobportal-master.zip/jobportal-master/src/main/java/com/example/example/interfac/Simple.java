package com.example.example.interfac;
class A
{
	private int data=40;
	private void msg()
	{
		System.out.println("Hello Java");	}
}
public class Simple
{
	public static void main(String args[])
	{
		A obj= new A();
	}
}