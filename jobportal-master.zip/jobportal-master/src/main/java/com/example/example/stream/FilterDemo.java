package com.example.example.stream;

import java.util.Arrays;
import java.util.List;

public class FilterDemo {
	public static void main(String[] args) {
		List<Product> productList=Arrays.asList(
                new Product(1,"iPhone",850),
                new Product(2,"samsung",700),
                new Product(3,"google",750),
                new Product(4,"lg",710),
                new Product(5,"blackberry",650),
                new Product(6,"nokia",600),
                new Product(7,"sony",750)
        );
		
		
	}

	
}
